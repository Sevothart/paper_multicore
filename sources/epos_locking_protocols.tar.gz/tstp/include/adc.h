// EPOS UART Mediator Common Package

#ifndef __adc_h
#define __adc_h

#include <system/config.h>

__BEGIN_SYS

class ADC_Common
{
protected:
    ADC_Common() {}

public:
};

__END_SYS

#ifdef __ADC_H
#include __ADC_H
#endif

#endif
