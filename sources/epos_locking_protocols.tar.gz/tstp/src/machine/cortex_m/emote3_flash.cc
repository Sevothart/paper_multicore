#include <system/config.h>
#include __MODEL_H
#ifdef __emote3_h

#include <flash.h>

__USING_SYS

eMote3_Flash::Data eMote3_Flash::data{};

#endif
