// EPOS-- ARMv7 MMU Mediator Implementation

#include <architecture/armv7/mmu.h>

__BEGIN_SYS

// Class attributes
ARMv7_MMU::List ARMv7_MMU::_free;

__END_SYS
