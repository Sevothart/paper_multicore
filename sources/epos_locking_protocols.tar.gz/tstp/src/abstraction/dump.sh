/usr/local/arm/gcc-4.4.4/bin/arm-objdump -s ${1} > ${1}.dump
