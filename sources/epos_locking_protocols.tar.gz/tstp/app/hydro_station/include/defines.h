#ifndef DEFINES_H_
#define DEFINES_H_

const auto MINUTES = 5u;
const auto MINUTE_IN_US = 60000000u;

#endif
